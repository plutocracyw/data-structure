/*******************************************************************************
* FileName:         SeqStack.cpp
* Author:           Your_Name
* Student Number:   3022244xxx
* Date:             2023/03/17 11:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #3
*******************************************************************************/
#include "SeqStack.h"

SeqStack::SeqStack(){

}
SeqStack::~SeqStack(){

}
void SeqStack::push_back(int data){

}
int SeqStack::top() const{

}
void SeqStack::pop(){

}